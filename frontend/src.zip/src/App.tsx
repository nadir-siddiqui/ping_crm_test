// frontend/src/App.tsx
import React from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import ContactsList from "./pages/ContactsList";
import ContactForm from "./pages/ContactForm";
import CompaniesList from "./pages/CompaniesList";
import CompanyForm from "./pages/CompanyForm";

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <div className="container mx-auto p-4">
        <nav className="mb-4">
          <Link className="mr-4 text-blue-600" to="/">Dashboard</Link>
          <Link className="mr-4 text-blue-600" to="/contacts">Contacts</Link>
          <Link className="mr-4 text-blue-600" to="/contacts/new">Add Contact</Link>
          <Link className="mr-4 text-blue-600" to="/companies">Companies</Link>
          <Link className="mr-4 text-blue-600" to="/companies/new">Add Company</Link>
        </nav>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/contacts" element={<ContactsList />} />
          <Route path="/contacts/new" element={<ContactForm />} />
          <Route path="/contacts/edit/:id" element={<ContactForm />} />
          <Route path="/companies" element={<CompaniesList />} />
          <Route path="/companies/new" element={<CompanyForm />} />
          <Route path="/companies/edit/:id" element={<CompanyForm />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
};

export default App;
