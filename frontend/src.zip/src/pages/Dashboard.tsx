// frontend/src/pages/Dashboard.tsx
import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchContacts, Contact } from "../store/contactsSlice";
import { fetchCompanies, Company } from "../store/companiesSlice";
import { RootState, AppDispatch } from "../store/store";
import { Link } from "react-router-dom";

const Dashboard: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();

  // Retrieve contacts and companies data from Redux store
  const { contacts, loading: contactsLoading, error: contactsError } = useSelector(
    (state: RootState) => state.contacts
  );
  const { companies, loading: companiesLoading, error: companiesError } = useSelector(
    (state: RootState) => state.companies
  );

  // Local state for filtering/searching
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCompany, setSelectedCompany] = useState(0); // 0 means "All Companies"

  // Fetch contacts and companies when the component mounts
  useEffect(() => {
    dispatch(fetchContacts());
  }, [dispatch]);

  useEffect(() => {
    dispatch(fetchCompanies());
  }, [dispatch]);

  // Filter the contacts by the search term and selected company
  const filteredContacts = contacts.filter((contact: Contact) => {
    const nameMatch = contact.name.toLowerCase().includes(searchTerm.toLowerCase());
    const companyMatch = selectedCompany === 0 || contact.company_id === selectedCompany;
    return nameMatch && companyMatch;
  });

  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
      
      {/* Filter Controls */}
      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        {/* Search Input */}
        <input
          type="text"
          placeholder="Search by contact name..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="border p-2 flex-1"
        />

        {/* Company Dropdown */}
        <select
          value={selectedCompany}
          onChange={(e) => setSelectedCompany(Number(e.target.value))}
          className="border p-2"
        >
          <option value={0}>All Companies</option>
          {companies.map((company: Company) => (
            <option key={company.id} value={company.id}>
              {company.name}
            </option>
          ))}
        </select>
      </div>

      {/* Loading/Error Messages */}
      {(contactsLoading || companiesLoading) && <p>Loading data...</p>}
      {(contactsError || companiesError) && <p>Error loading data: {contactsError || companiesError}</p>}

      {/* Contacts Table */}
      {filteredContacts.length > 0 ? (
        <table className="min-w-full border-collapse border">
          <thead>
            <tr>
              <th className="border px-4 py-2">Name</th>
              <th className="border px-4 py-2">Phone</th>
              <th className="border px-4 py-2">City</th>
              <th className="border px-4 py-2">Company</th>
              <th className="border px-4 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredContacts.map((contact: Contact) => {
              const company = companies.find((c: Company) => c.id === contact.company_id);
              return (
                <tr key={contact.id}>
                  <td className="border px-4 py-2">{contact.name}</td>
                  <td className="border px-4 py-2">{contact.phone}</td>
                  <td className="border px-4 py-2">{contact.city}</td>
                  <td className="border px-4 py-2">{company ? company.name : "N/A"}</td>
                  <td className="border px-4 py-2">
                    {/* Link to edit page */}
                    <Link className="text-blue-500" to={`/contacts/edit/${contact.id}`}>
                      Edit
                    </Link>
                    {/* You can add a delete button here as well if desired */}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      ) : (
        <p>No contacts match your search criteria.</p>
      )}
    </div>
  );
};

export default Dashboard;
